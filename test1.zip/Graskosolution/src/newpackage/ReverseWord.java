package newpackage;
import java.util.*;
public class ReverseWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	     System.out.print("\n enter word: ");
		 String word =sc.nextLine();
		 word = word.trim();
		 String result = ""; 
	     char[] ch=word.toCharArray();  
		 for (int i = ch.length - 1; i >= 0; i--) 
		 {
				 result += ch[i];
			 }
		 System.out.println("Reverse word: "+result.trim()); 
		 }			
	
}



package newpackage;
import java.util.*;
public class Convertstringtoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     System.out.println("enter value");
     String s=sc.nextLine();
     int a=Integer.parseInt(s);
     System.out.printf("integer value is : %d",a);
	}

}

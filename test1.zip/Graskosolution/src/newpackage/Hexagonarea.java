package newpackage;
import java.util.Scanner;
public class Hexagonarea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     System.out.println("enter number");
     int a=sc.nextInt();
     double area=(3*Math.sqrt(3)*Math.pow(a,2))/2.0;
     System.out.println("Area of hexagon "+area);
	}

}

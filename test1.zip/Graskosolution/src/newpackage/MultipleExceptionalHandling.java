package newpackage;
import java.io.*;

public class MultipleExceptionalHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try {
    	   int a=2/0;
    	  
    	   System.out.println(a);
       }
       catch(ArithmeticException e)
       {
    	   System.out.println(e);
       }
       try {
    	   int b[]= {2,3,5,7,8};
    	   System.out.println(b[7]);
       }
       catch(ArrayIndexOutOfBoundsException e)
       {
    	   System.out.println(e);
       }
       
	}
}

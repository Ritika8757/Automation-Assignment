package newpackage;
import java.util.Scanner;
public class IntegerSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num,sum=0,a;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		a= sc.nextInt();
		while(a>0)
		{
			num=a%10;
			sum=sum+num;
			a=a/10;
		}
	 System.out.println("sum of digit:"+sum);
    }
	}



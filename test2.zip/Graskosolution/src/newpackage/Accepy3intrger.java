package newpackage;
import java.util.*;
public class Accepy3intrger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		        Scanner sc = new Scanner(System.in);
		        System.out.print("first number : ");
		        int a = sc.nextInt();  
				System.out.print("second number: ");
				int b = sc.nextInt(); 
				System.out.print("third number : ");
		        int c = sc.nextInt(); 
		        System.out.print("The result is: "+rightmostdigit(a, b, c,true));
				System.out.print("\n");
		    }
		   
		    public static boolean rightmostdigit(int p, int q, int r, boolean abc)
		     {
			     return (p % 10 == q % 10) || (p % 10 == r % 10) || (q % 10 == r % 10);
		     }
		}

	


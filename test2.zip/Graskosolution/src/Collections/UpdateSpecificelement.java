package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class UpdateSpecificelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ArrayList <String> list=new ArrayList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   //update element in list
		   list.set(1, "Purple");
		   
		   Iterator itr=list.iterator();
		   while(itr.hasNext())
		   {
			   System.out.println(itr.next());
		   }
			}

		}
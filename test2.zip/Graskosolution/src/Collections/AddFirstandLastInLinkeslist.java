package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class AddFirstandLastInLinkeslist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <String> list=new LinkedList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   System.out.println("linked list is "+list);
		   
		   list.addFirst("Pink");
		   list.addLast("Yellow");
		   
		   System.out.println("linked list after adding is "+list);
	}

}

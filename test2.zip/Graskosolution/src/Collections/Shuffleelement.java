package Collections;
import java.util.*;

public class Shuffleelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		 ArrayList <String> list=new ArrayList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   Iterator itr=list.iterator();
		   while(itr.hasNext())
		   {
			   System.out.println(itr.next());
		   }
			
	Collections.shuffle(list);
	 System.out.println("After shuffle \n");
     System.out.println(list);
		}
}
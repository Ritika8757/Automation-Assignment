package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class IteratewithSpecificposition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <String> list=new LinkedList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   
		   Iterator itr=list.listIterator(1);
		   while(itr.hasNext())
		   {
			   System.out.println(itr.next());
		   }
	}

}

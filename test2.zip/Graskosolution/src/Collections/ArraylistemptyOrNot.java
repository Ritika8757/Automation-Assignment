package Collections;
import java.util.*;
import java.util.ArrayList;

public class ArraylistemptyOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArrayList <String> list=new ArrayList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   if(list.isEmpty())
		   {
			   System.out.println("\n Array list is empty");
		   }
		   else
		   {
			   System.out.println("\n Array list is not  empty");
		   }
	}

}

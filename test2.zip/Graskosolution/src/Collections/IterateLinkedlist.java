package Collections;
import java.util.*;
public class IterateLinkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <String> list=new LinkedList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   Iterator itr=list.iterator();
		   while(itr.hasNext())
		   {
			   System.out.println(itr.next());
		   }
	}

}

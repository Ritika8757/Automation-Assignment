package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class ReverseOrderLinkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <String> list=new LinkedList<String>();
		   list.add("Black");
		   list.add("White");
		   list.add("Red");
		   list.add("Green");
		   list.add("Blue");
		   
		   System.out.println("linked list is "+list);
		   Iterator itr=list.descendingIterator();
		   
		   System.out.println("Reverse order list \n");
		   while(itr.hasNext())
		   {
			   System.out.println(itr.next());
		   }

	}

}

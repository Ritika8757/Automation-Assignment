package day1andday2;
import java.util.*;
public class FactorialofNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,factorial=1,n;
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("enter no");
		 n=sc.nextInt();
		 
		 for(i=1;i<=n;i++)
		 {
			 factorial=factorial*i;
		 }
		
		 System.out.println("factorial of a number "+factorial);
	}

}

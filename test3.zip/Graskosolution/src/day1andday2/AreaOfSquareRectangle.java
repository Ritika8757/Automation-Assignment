package day1andday2;

public class AreaOfSquareRectangle {

	public int area(int side)
	{
		return (side*side);
	}
	public int area(int length ,int breadth)
	{
		return (length*breadth);
	}


	public static void main(String[] args) {
		AreaOfSquareRectangle a=new AreaOfSquareRectangle();
		System.out.println("area of square ="+a.area(4));
		System.out.println("area of rectangle ="+a.area(4,5));

	}
	}
 


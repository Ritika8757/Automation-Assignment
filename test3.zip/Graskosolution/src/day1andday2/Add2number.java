package day1andday2;

import java.util.Scanner;

public class Add2number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,sum=0;
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("enter first no");
		 a=sc.nextInt();
		 System.out.println("enter second  no");
		 b=sc.nextInt();
		 sum=a+b;
		 System.out.println("sum is "+sum);
	}

}

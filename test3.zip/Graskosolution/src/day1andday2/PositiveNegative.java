package day1andday2;

import java.util.Scanner;

public class PositiveNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("enter no");
		 n=sc.nextInt();
		 if(n>0)
			{
				System.out.println("number is positive");
		}
		 
		 else if(n<0)
		{
			System.out.println("number is negative");
	}
		
	}

}

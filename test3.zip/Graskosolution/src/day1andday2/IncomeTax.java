package day1andday2;
import java.util.Scanner;
public class IncomeTax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);

		int amount=sc.nextInt();

		if(amount<=50000)
		{
         System.out.println("amount is "+ amount);
         }

		else if(amount<=60000){
			amount+=(amount/100)*10;
          System.out.println("amount is "+ amount);
          }
       else if(amount <=150000){

		amount+=(amount/100)*20;

		System.out.println("amount is "+ amount);
         }

		else

		{

		amount+=(amount/100)*30;

		System.out.println("amount is"+ amount);

		}
       

		}

}
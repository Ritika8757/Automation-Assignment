package day1andday2;
import java.util.*;
public class FindASCIIvalue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int c='a';
  System.out.println("ASCII  value is "+c);
	}

}

package day1andday2;

import java.util.Scanner;

public class Multiply2number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,mul;
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("enter first no");
		 a=sc.nextInt();
		 System.out.println("enter second  no");
		 b=sc.nextInt();
		 mul=a*b;
		 System.out.println("multplication of 2 number  is "+mul);
	}

}

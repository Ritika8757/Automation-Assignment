package day1andday2;

import java.util.Scanner;

public class AreaofTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float h,b,area;
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("enter base");
		 b=sc.nextInt();
		 System.out.println("enter height  ");
		 h=sc.nextInt();
		 area=(b*h)/2;
		 System.out.println("Area of triangle is "+area);
	}

}

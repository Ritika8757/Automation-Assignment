package day1andday2;

class Time
{

	 int hours;  
    int minutes; 
     int seconds; 


    public Time(int h, int m, int s)
    {
	      hours=h;
	      minutes=m;
	      seconds=s;
	      
    }

    public void isTimevalid()
    {
	      if(hours>=0  && hours < 24  &&  minutes>0 && minutes < 60 && seconds>0 && seconds < 60)
	    	  System.out.println("time is valid");
    
    else 
    {
    	System.out.println("time is not valid");
    }
    }
    public void setTimeMode()
    {
    	if(hours<12)
    	{
    		System.out.println("time =" +hours +":"+minutes+":"+seconds+"AM");
    	}
    	else
    	{
    		hours=hours-12;
    		System.out.println("time =" +hours +":"+minutes+":"+seconds+"PM");
    	}
    }
}
    public class Clock {
	public static void main(String[] args) {
		Time c1=new Time(16,34,45);
		c1.isTimevalid();
		c1.setTimeMode();
		
	}

}

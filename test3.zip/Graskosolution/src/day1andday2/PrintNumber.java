package day1andday2;

public class PrintNumber {
	public int printn(int a)
	{
		return a;
	}
   public float printn(float b)
   {
	   return b;
   }
   public double printn(double c)
   {
	   return c;
   }
   public long printn(long d)
   {
	   return d;
   }
   public short printn(short e)
   {
	   return e;
   }
	public static void main(String[] args) {
		PrintNumber n=new PrintNumber();
		System.out.println(n.printn(8));
		System.out.println(n.printn(8.0032D));

		System.out.println(n.printn(8.78F));

		System.out.println(n.printn(898798635L));
		System.out.println(n.printn(865));


	}

}

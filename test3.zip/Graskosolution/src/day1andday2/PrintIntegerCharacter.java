package day1andday2;

public class PrintIntegerCharacter {
	public void intchar(int n,char c)
	{
		
	System.out.println("Integer is "+n);
	System.out.println("character  is "+c);
		
	}
	public void intchar(char c,int n)
	{
		System.out.println("character  is "+c);
		System.out.println("Integer is "+n);
	}


	public static void main(String[] args) {
		PrintIntegerCharacter a=new PrintIntegerCharacter();
		a.intchar(2,'p');
		a.intchar('p',8);
				
	}

}

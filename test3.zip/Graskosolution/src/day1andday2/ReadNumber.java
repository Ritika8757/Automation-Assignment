package day1andday2;

import java.util.Scanner;

public class ReadNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int n;
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("enter no");
		 n=sc.nextInt();
		 
		 System.out.println("number enter by user "+n);
	}

}
